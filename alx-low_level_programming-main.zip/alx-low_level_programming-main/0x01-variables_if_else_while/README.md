Learning about variables and loops
