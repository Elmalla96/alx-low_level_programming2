Learing the compilation process
